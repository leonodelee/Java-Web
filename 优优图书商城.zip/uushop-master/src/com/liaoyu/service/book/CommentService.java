package com.liaoyu.service.book;

import com.liaoyu.bean.book.Comment;
import com.liaoyu.service.Dao;

public interface CommentService extends Dao<Comment> {

}
