package com.liaoyu.bean.user;

public enum Type {
	GENERAL,
	MANAGER
}
